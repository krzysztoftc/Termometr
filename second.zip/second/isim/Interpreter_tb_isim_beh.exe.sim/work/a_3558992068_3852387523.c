/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/lab/Desktop/second/Interpreter.vhd";
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_180853171_1035706684(char *, char *, int , int );
int ieee_p_1242562249_sub_2271993008_1035706684(char *, char *, char *);


static void work_a_3558992068_3852387523_p_0(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(44, ng0);

LAB3:    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = (15 - 15);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 2072);
    t9 = (t8 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast_port(t8);

LAB2:    t13 = (t0 + 2012);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3558992068_3852387523_p_1(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(46, ng0);

LAB3:    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = (0 - 15);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 2108);
    t9 = (t8 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast_port(t8);

LAB2:    t13 = (t0 + 2020);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3558992068_3852387523_p_2(char *t0)
{
    char t18[16];
    char t24[16];
    char t37[16];
    char t42[16];
    unsigned char t1;
    char *t2;
    char *t3;
    int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned char t8;
    unsigned char t9;
    char *t10;
    char *t11;
    int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned char t16;
    unsigned char t17;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t25;
    char *t26;
    int t27;
    unsigned int t28;
    int t29;
    int t30;
    int t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t38;
    char *t39;
    unsigned int t40;
    unsigned int t41;
    char *t43;
    char *t44;
    int t45;
    unsigned int t46;
    int t47;
    int t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;

LAB0:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 592U);
    t3 = *((char **)t2);
    t4 = (15 - 15);
    t5 = (t4 * -1);
    t6 = (1U * t5);
    t7 = (0 + t6);
    t2 = (t3 + t7);
    t8 = *((unsigned char *)t2);
    t9 = (t8 == (unsigned char)3);
    if (t9 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB8:    t38 = (t0 + 592U);
    t39 = *((char **)t38);
    t28 = (15 - 8);
    t40 = (t28 * 1U);
    t41 = (0 + t40);
    t38 = (t39 + t41);
    t43 = (t42 + 0U);
    t44 = (t43 + 0U);
    *((int *)t44) = 8;
    t44 = (t43 + 4U);
    *((int *)t44) = 1;
    t44 = (t43 + 8U);
    *((int *)t44) = -1;
    t45 = (1 - 8);
    t46 = (t45 * -1);
    t46 = (t46 + 1);
    t44 = (t43 + 12U);
    *((unsigned int *)t44) = t46;
    t47 = ieee_p_1242562249_sub_2271993008_1035706684(IEEE_P_1242562249, t38, t42);
    t48 = (t47>=0?t47: -t47);
    t44 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t37, t48, 7);
    t49 = (t0 + 2144);
    t50 = (t49 + 32U);
    t51 = *((char **)t50);
    t52 = (t51 + 40U);
    t53 = *((char **)t52);
    memcpy(t53, t44, 7U);
    xsi_driver_first_trans_fast_port(t49);

LAB2:    t54 = (t0 + 2028);
    *((int *)t54) = 1;

LAB1:    return;
LAB3:    t19 = (t0 + 592U);
    t20 = *((char **)t19);
    t21 = (15 - 8);
    t22 = (t21 * 1U);
    t23 = (0 + t22);
    t19 = (t20 + t23);
    t25 = (t24 + 0U);
    t26 = (t25 + 0U);
    *((int *)t26) = 8;
    t26 = (t25 + 4U);
    *((int *)t26) = 1;
    t26 = (t25 + 8U);
    *((int *)t26) = -1;
    t27 = (1 - 8);
    t28 = (t27 * -1);
    t28 = (t28 + 1);
    t26 = (t25 + 12U);
    *((unsigned int *)t26) = t28;
    t29 = ieee_p_1242562249_sub_2271993008_1035706684(IEEE_P_1242562249, t19, t24);
    t30 = (t29>=0?t29: -t29);
    t31 = (t30 - 1);
    t26 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t18, t31, 7);
    t32 = (t0 + 2144);
    t33 = (t32 + 32U);
    t34 = *((char **)t33);
    t35 = (t34 + 40U);
    t36 = *((char **)t35);
    memcpy(t36, t26, 7U);
    xsi_driver_first_trans_fast_port(t32);
    goto LAB2;

LAB5:    t10 = (t0 + 592U);
    t11 = *((char **)t10);
    t12 = (0 - 15);
    t13 = (t12 * -1);
    t14 = (1U * t13);
    t15 = (0 + t14);
    t10 = (t11 + t15);
    t16 = *((unsigned char *)t10);
    t17 = (t16 == (unsigned char)3);
    t1 = t17;
    goto LAB7;

LAB9:    goto LAB2;

}


extern void work_a_3558992068_3852387523_init()
{
	static char *pe[] = {(void *)work_a_3558992068_3852387523_p_0,(void *)work_a_3558992068_3852387523_p_1,(void *)work_a_3558992068_3852387523_p_2};
	xsi_register_didat("work_a_3558992068_3852387523", "isim/Interpreter_tb_isim_beh.exe.sim/work/a_3558992068_3852387523.didat");
	xsi_register_executes(pe);
}
