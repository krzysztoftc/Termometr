/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/lab/Desktop/second/doble_dabble_module.vhd";
extern char *IEEE_P_3620187407;
extern char *IEEE_P_2592010699;

unsigned char ieee_p_3620187407_sub_2546454082_3965413181(char *, char *, char *, int );
char *ieee_p_3620187407_sub_436279890_3965413181(char *, char *, char *, char *, int );


static void work_a_2600304128_3212880686_p_0(char *t0)
{
    char t10[16];
    char t16[16];
    char t20[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    int t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    char *t11;
    char *t12;
    int t13;
    unsigned int t14;
    unsigned char t15;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    char *t21;
    char *t22;
    int t23;
    unsigned int t24;
    char *t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;

LAB0:    xsi_set_current_line(50, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 1040U);
    t3 = *((char **)t1);
    t1 = (t3 + 0);
    memcpy(t1, t2, 7U);
    xsi_set_current_line(51, ng0);
    t1 = xsi_get_transient_memory(12U);
    memset(t1, 0, 12U);
    t2 = t1;
    memset(t2, (unsigned char)2, 12U);
    t3 = (t0 + 1108U);
    t4 = *((char **)t3);
    t3 = (t4 + 0);
    memcpy(t3, t1, 12U);
    xsi_set_current_line(53, ng0);
    t1 = (t0 + 3478);
    *((int *)t1) = 0;
    t2 = (t0 + 3482);
    *((int *)t2) = 6;
    t5 = 0;
    t6 = 6;

LAB2:    if (t5 <= t6)
        goto LAB3;

LAB5:    xsi_set_current_line(68, ng0);
    t1 = (t0 + 1108U);
    t2 = *((char **)t1);
    t7 = (11 - 3);
    t8 = (t7 * 1U);
    t9 = (0 + t8);
    t1 = (t2 + t9);
    t3 = (t0 + 1904);
    t4 = (t3 + 32U);
    t11 = *((char **)t4);
    t12 = (t11 + 40U);
    t17 = *((char **)t12);
    memcpy(t17, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(69, ng0);
    t1 = (t0 + 1108U);
    t2 = *((char **)t1);
    t7 = (11 - 7);
    t8 = (t7 * 1U);
    t9 = (0 + t8);
    t1 = (t2 + t9);
    t3 = (t0 + 1940);
    t4 = (t3 + 32U);
    t11 = *((char **)t4);
    t12 = (t11 + 40U);
    t17 = *((char **)t12);
    memcpy(t17, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(70, ng0);
    t1 = (t0 + 1108U);
    t2 = *((char **)t1);
    t7 = (11 - 11);
    t8 = (t7 * 1U);
    t9 = (0 + t8);
    t1 = (t2 + t9);
    t3 = (t0 + 1976);
    t4 = (t3 + 32U);
    t11 = *((char **)t4);
    t12 = (t11 + 40U);
    t17 = *((char **)t12);
    memcpy(t17, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    t1 = (t0 + 1860);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(54, ng0);
    t3 = (t0 + 1108U);
    t4 = *((char **)t3);
    t7 = (11 - 3);
    t8 = (t7 * 1U);
    t9 = (0 + t8);
    t3 = (t4 + t9);
    t11 = (t10 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 3;
    t12 = (t11 + 4U);
    *((int *)t12) = 0;
    t12 = (t11 + 8U);
    *((int *)t12) = -1;
    t13 = (0 - 3);
    t14 = (t13 * -1);
    t14 = (t14 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t14;
    t15 = ieee_p_3620187407_sub_2546454082_3965413181(IEEE_P_3620187407, t3, t10, 4);
    if (t15 != 0)
        goto LAB6;

LAB8:
LAB7:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 1108U);
    t2 = *((char **)t1);
    t7 = (11 - 7);
    t8 = (t7 * 1U);
    t9 = (0 + t8);
    t1 = (t2 + t9);
    t3 = (t10 + 0U);
    t4 = (t3 + 0U);
    *((int *)t4) = 7;
    t4 = (t3 + 4U);
    *((int *)t4) = 4;
    t4 = (t3 + 8U);
    *((int *)t4) = -1;
    t13 = (4 - 7);
    t14 = (t13 * -1);
    t14 = (t14 + 1);
    t4 = (t3 + 12U);
    *((unsigned int *)t4) = t14;
    t15 = ieee_p_3620187407_sub_2546454082_3965413181(IEEE_P_3620187407, t1, t10, 4);
    if (t15 != 0)
        goto LAB9;

LAB11:
LAB10:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 1108U);
    t2 = *((char **)t1);
    t7 = (11 - 10);
    t8 = (t7 * 1U);
    t9 = (0 + t8);
    t1 = (t2 + t9);
    t3 = (t0 + 1040U);
    t4 = *((char **)t3);
    t13 = (6 - 6);
    t14 = (t13 * -1);
    t18 = (1U * t14);
    t19 = (0 + t18);
    t3 = (t4 + t19);
    t15 = *((unsigned char *)t3);
    t12 = ((IEEE_P_2592010699) + 2332);
    t17 = (t16 + 0U);
    t21 = (t17 + 0U);
    *((int *)t21) = 10;
    t21 = (t17 + 4U);
    *((int *)t21) = 0;
    t21 = (t17 + 8U);
    *((int *)t21) = -1;
    t23 = (0 - 10);
    t24 = (t23 * -1);
    t24 = (t24 + 1);
    t21 = (t17 + 12U);
    *((unsigned int *)t21) = t24;
    t11 = xsi_base_array_concat(t11, t10, t12, (char)97, t1, t16, (char)99, t15, (char)101);
    t21 = (t0 + 1108U);
    t22 = *((char **)t21);
    t21 = (t22 + 0);
    t24 = (11U + 1U);
    memcpy(t21, t11, t24);
    xsi_set_current_line(64, ng0);
    t1 = (t0 + 1040U);
    t2 = *((char **)t1);
    t7 = (6 - 5);
    t8 = (t7 * 1U);
    t9 = (0 + t8);
    t1 = (t2 + t9);
    t4 = ((IEEE_P_2592010699) + 2332);
    t11 = (t16 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 5;
    t12 = (t11 + 4U);
    *((int *)t12) = 0;
    t12 = (t11 + 8U);
    *((int *)t12) = -1;
    t13 = (0 - 5);
    t14 = (t13 * -1);
    t14 = (t14 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t14;
    t3 = xsi_base_array_concat(t3, t10, t4, (char)97, t1, t16, (char)99, (unsigned char)2, (char)101);
    t12 = (t0 + 1040U);
    t17 = *((char **)t12);
    t12 = (t17 + 0);
    t14 = (6U + 1U);
    memcpy(t12, t3, t14);

LAB4:    t1 = (t0 + 3478);
    t5 = *((int *)t1);
    t2 = (t0 + 3482);
    t6 = *((int *)t2);
    if (t5 == t6)
        goto LAB5;

LAB12:    t13 = (t5 + 1);
    t5 = t13;
    t3 = (t0 + 3478);
    *((int *)t3) = t5;
    goto LAB2;

LAB6:    xsi_set_current_line(55, ng0);
    t12 = (t0 + 1108U);
    t17 = *((char **)t12);
    t14 = (11 - 3);
    t18 = (t14 * 1U);
    t19 = (0 + t18);
    t12 = (t17 + t19);
    t21 = (t20 + 0U);
    t22 = (t21 + 0U);
    *((int *)t22) = 3;
    t22 = (t21 + 4U);
    *((int *)t22) = 0;
    t22 = (t21 + 8U);
    *((int *)t22) = -1;
    t23 = (0 - 3);
    t24 = (t23 * -1);
    t24 = (t24 + 1);
    t22 = (t21 + 12U);
    *((unsigned int *)t22) = t24;
    t22 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t16, t12, t20, 3);
    t25 = (t0 + 1108U);
    t26 = *((char **)t25);
    t24 = (11 - 3);
    t27 = (t24 * 1U);
    t28 = (0 + t27);
    t25 = (t26 + t28);
    t29 = (t16 + 12U);
    t30 = *((unsigned int *)t29);
    t31 = (1U * t30);
    memcpy(t25, t22, t31);
    goto LAB7;

LAB9:    xsi_set_current_line(59, ng0);
    t4 = (t0 + 1108U);
    t11 = *((char **)t4);
    t14 = (11 - 7);
    t18 = (t14 * 1U);
    t19 = (0 + t18);
    t4 = (t11 + t19);
    t12 = (t20 + 0U);
    t17 = (t12 + 0U);
    *((int *)t17) = 7;
    t17 = (t12 + 4U);
    *((int *)t17) = 4;
    t17 = (t12 + 8U);
    *((int *)t17) = -1;
    t23 = (4 - 7);
    t24 = (t23 * -1);
    t24 = (t24 + 1);
    t17 = (t12 + 12U);
    *((unsigned int *)t17) = t24;
    t17 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t16, t4, t20, 3);
    t21 = (t0 + 1108U);
    t22 = *((char **)t21);
    t24 = (11 - 7);
    t27 = (t24 * 1U);
    t28 = (0 + t27);
    t21 = (t22 + t28);
    t25 = (t16 + 12U);
    t30 = *((unsigned int *)t25);
    t31 = (1U * t30);
    memcpy(t21, t17, t31);
    goto LAB10;

}


extern void work_a_2600304128_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2600304128_3212880686_p_0};
	xsi_register_didat("work_a_2600304128_3212880686", "isim/double_dabble_tb2_isim_beh.exe.sim/work/a_2600304128_3212880686.didat");
	xsi_register_executes(pe);
}
